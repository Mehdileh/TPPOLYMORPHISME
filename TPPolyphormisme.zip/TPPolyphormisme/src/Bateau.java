// Sub - classe Bateau
class Bateau extends Vehicule {

    // Constructor
    public Bateau() {
        super(40);  // Vitesse moyenne = 40 km/h
    }

    // Overriding calculerTempsTrajet() pour calculer le temps de trajet de Bateau
    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}
