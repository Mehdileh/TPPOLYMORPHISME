// Classe Main
public class Main {
    public static void main(String[] args) {
        double distance = 150;  // KM

        // tableau de références Véhicules
        Vehicule[] vehicules = { new Voiture(), new Velo(), new Bateau() };

        // Calcul et affichage du temps de trajet pour chaque type véhicule
        for (Vehicule v : vehicules) {
            System.out.println("Temps de trajet pour " + v.getClass().getSimpleName() + ": " + v.calculerTempsTrajet(distance) + " heures.");
        }
    }
}
