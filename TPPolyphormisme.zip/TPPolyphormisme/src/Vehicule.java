// Classe abstraite Véhicule
abstract class Vehicule {
    protected double vitesseMoyenne;

    // Constructor
    public Vehicule(double vitesseMoyenne) {
        this.vitesseMoyenne = vitesseMoyenne;
    }

    // Méthode abstraite calculerTempsTrajet :

    public abstract double calculerTempsTrajet(double distance);
}
