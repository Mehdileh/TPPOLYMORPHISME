// Sub - classe Velo
class Velo extends Vehicule {

    // Constructor
    public Velo() {
        super(15);  // Vitesse moyenne = 15 km/h
    }

    // Overriding calculerTempsTrajet() pour calculer le temps de trajet de Velo
    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}

