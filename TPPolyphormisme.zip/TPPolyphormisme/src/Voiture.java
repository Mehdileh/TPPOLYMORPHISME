// Subclasse - Voiture
class Voiture extends Vehicule {

    // Constructor
    public Voiture() {
        super(100);  // Vitesse moyenne = 100 km/h
    }

    // Overriding calculerTempsTrajet() pour calculer le temps de trajet de voiture
    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}

